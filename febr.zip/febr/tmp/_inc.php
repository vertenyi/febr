<?php
include_once('inc/db.php');
include_once('inc/user.php');
include_once('inc/blog.php');
include_once('inc/cat.php');
include_once('inc/file.php');


?>