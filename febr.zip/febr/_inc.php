<?php
require_once  'inc/statics.php';
require_once  'inc/db.php';
require_once  'inc/user.php';
require_once  'inc/cat.php';
require_once  'inc/blog.php';
require_once  'inc/publication.php';
require_once  'inc/file.php';
?>