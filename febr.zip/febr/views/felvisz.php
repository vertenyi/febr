<?php 

// initialize default values, in case they don't exist
$rtTitle = '';
$text = '';
$selectedCat = '';
$rtId = 0;
if (isset($_GET['delete'])){
	$CRUD_Delete = new Blog();
	$CRUD_Delete->deleteArticle($_GET['delete']);	
	
}else if (isset($_POST['rtArea'])){
	$rtId = $_POST['rtId'];
	$text = $_POST['rtArea'];
	$text = Statics::sanitize($text);
	$rtTitle = $_POST['rtTitle'];
	if($_POST['selectcategory']>0){$selectedCat=$_POST['selectcategory'];}
	else{$selectedCat=0;}
	
	$text = preg_replace("/\r\n|\r|\n/", '', $text);
	$text = str_replace(array("\r\n", "\n", "\r"), '', $text);
	$text = str_replace(PHP_EOL, '', $text);
	
	echo '<h5>You posted on '.date('Y F dS, D H:i:s').'</h5><article><h2>'. $rtTitle . '</h2><div class="text">' . $text . '</div></article>';

	// 				(cat_id,par_id,title,meta,text,code,tags,img,user)
	$userid = $_SESSION['user']['id'];
	if($rtId > 0){
		// (id,cat_id,par_id,title,meta,text,code,tags,img,user)
		$set = "cat_id='$selectedCat',par_id=0,title='$rtTitle',meta='',text='$text',code='',tags='',img='',user='$userid'";
		echo $set;
		$CRUD_Update = new UpdateBlog();
		$CRUD_Update->updateArticle($rtId, $set);	
	}else{
		$article = array($selectedCat,0,$rtTitle,'',$text,'code','test','_',$userid);
		$CRUD_Create = new Blog();
		$CRUD_Create->newArticle($article);
	}
}
else if (isset($_GET['edit'])){
	$getArticle = new Blog();
	$article = $getArticle->getArticle($_GET['edit']);
	$rtTitle = $article['title'];
	$text = $article['text'];
	$selectedCat = $article['cat_id'];
	$rtId = $_GET['edit'];
}
?>

<script type="text/javascript"  src="js/rtf.js"></script>
<div>
<form action="index.php?menu=felvisz" name="rtForm" id="rtForm" method="post">
<p>Title: 
	<input name="rtId" id="rtId" type="number" value="<?=$rtId?>" readonly class="hidden">
	<input name="rtTitle" id="rtTitle" type="text" value="<?=$rtTitle?>">
	

<?php  if (isset($_GET['edit'])){
	echo '<input name="editBtn" type="button" value="edit" class="btn" onClick="javascript:submitform();"/>';
}else{ 
	echo '<input name="saveBtn" type="button" value="Save" class="btn" onClick="javascript:submitform();"/>';
}
?>	
</p>
<p>Category: 
<?php
	$SelectCat=new SelectCat($selectedCat);

?>
</p>

<div id="rtControlPanel">
  <span class="btn" onClick="doBold()" title="bold">
	<b>b</b>
  </span> 
  <span class="btn" onClick="doUnderline()" title="underline">
	<u>u</u>
  </span>
  <span class="btn" onClick="doItalic()" title="italic">
	<i style="visibility: hidden;">i</i><i style="text-transform: lowercase;">i</i>
  </span>
  <span class="btn" onClick="doSize()" title="font-size">
	Text Size
  </span>
  <span class="btn" onClick="doColor()" title="font-color">
	Color
  </span>
  <span class="btn" onClick="doHr()" title="horizontal rule">
	-
  </span>
  <span class="btn" onClick="doUl()" title="unordered list">
	ul
  </span>
  <span class="btn" onClick="doOl()" title="ordered list">
	ol
  </span>
  <span class="btn" onClick="doLink()" title="link">
	href:
  </span>
  <span class="btn" onClick="doUnLink()" title="disable link">
	unlink
  </span>
  <span class="btn" onClick="doImage()" title="image">
	image
  </span>
</div>



<textarea name="rtArea" id="rtArea" cols="100" rows="14"></textarea>
<iframe name="rtField" id="rtField" class="article"></iframe>
<script>
var doc = document.getElementById('rtField').contentWindow.document;
doc.open();
doc.write('<?=$text?>');
doc.close();
</script>



</form>
</div>
