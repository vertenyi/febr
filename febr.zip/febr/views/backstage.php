<?php
if(isset($bck)){  // if there is a backstage message, then
	echo '<pre class="backstage">';
	for($i=0; $i<count($bck);$i++) {
		echo $bck[$i];
	}
	echo '</pre>';	
unset ($bck); // unset backstage message
}
	
?>