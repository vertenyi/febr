<?php 
$list = new CategoryTable();


// frequent reload loop
echo '<meta http-equiv="refresh" content="30"/>';

?>