<?php 

$SelectCategory=new SelectCategory('index.php?menu=list');

if(isset($_POST['selectcategory'])){
	$list = new DisplayBlog();
	$list->showBlogByCat($_POST['selectcategory']);
}else if(isset($_GET['catid'])){
	$list = new DisplayBlog();
	$list->showBlogByCat($_GET['catid']);
}

//$list = new DisplayBlog();
//$list->showBlogByCat(0);

echo '<hr>';


?>